import React, { useEffect, useContext, useState } from 'react';
import { FirebaseContext } from '../../store/Context';
import Heart from '../../assets/Heart';
import './Post.css';
import { PostContext } from '../../store/PostContext';
import { useHistory } from 'react-router-dom'

function Posts() {
  const history = useHistory()
  const { firebase } = useContext(FirebaseContext)
  const [products, setProducts] = useState([])
  const { setPostDetails } = useContext(PostContext)
  useEffect(() => {
    firebase.firestore().collection('products').get().then((snapshot) => {
      const allPosts = snapshot.docs.map((product) => {
        return {
          ...product.data(),
          id: product.id
        }
      })
      setProducts(allPosts)
    })
  })

  return (
    <div className="postParentDiv">
      <div className="moreView">
        <div className="heading">
          <span>Quick Menu</span>
          <span>View more</span>
        </div>
        <div className="cards">
          {products.map((product) => {


            return (
              <div className="card" onClick={() => {
                setPostDetails(product)
                history.push('/view')
              }}>
                <div className="favorite">
                  <Heart></Heart>
                </div>
                <div className="image">
                  <img src={product.url} alt="" />
                </div>
                <div className="content">
                  <p className="rate">&#x20B9; {product.price}</p>
                  <span className="kilometer">{product.name}</span>
                  <p className="name"> {product.category}</p>
                </div>
                <div className="date">
                  <span>{product.createdAt}</span>
                </div>
              </div>
            )
          })
          }
        </div>
      </div>
      <div className="recommendations">
        <div className="heading">
          <span>Fresh recommendations</span>
        </div>
        <div className="cards">
          <div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/R15V3.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 1,50,000</p>
              <span className="kilometer">Yamaha R15 V3</span>
              <p className="name"> 4800 km  2021 Model</p>
            </div>
            <div className="date">
              <span>12/10/2022</span>
            </div>
          </div>
          <div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/car2.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 3,50,000</p>
              <span className="kilometer">Ford Ecosport</span>
              <p className="name">24000 km 2017 Model</p>
            </div>
            <div className="date">
              <span>1/10/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/dum.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 2,800</p>
              <span className="kilometer">Home Gym</span>
              <p className="name"> Dumbell and rod</p>
            </div>
            <div className="date">
              <span>2/10/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/ref.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 13,000</p>
              <span className="kilometer">Lg Refrigerator</span>
              <p className="name">Single door  2018 Model</p>
            </div>
            <div className="date">
              <span>27/9/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/car.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 4,50,000</p>
              <span className="kilometer">Audi Q3</span>
              <p className="name">40000 km 2017 model</p>
            </div>
            <div className="date">
              <span>26/9/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/mi1.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 1,200</p>
              <span className="kilometer">Mi TV fire Stick</span>
              <p className="name">1 Month Old</p>
            </div>
            <div className="date">
              <span>1/10/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/sofa.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 23,000</p>
              <span className="kilometer">Wooden Sofa Set</span>
              <p className="name"> Teakwood</p>
            </div>
            <div className="date">
              <span>30/9/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/ps.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 1,800</p>
              <span className="kilometer">X-Box Controller</span>
              <p className="name"> Bill Box Available</p>
            </div>
            <div className="date">
              <span>19/10/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/jeans.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 750</p>
              <span className="kilometer">Flying Machine Jeans</span>
              <p className="name">Waist 32 Blue Stretchable</p>
            </div>
            <div className="date">
              <span>7/10/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/watch.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9;1,200</p>
              <span className="kilometer">UCB Watch</span>
              <p className="name">White dial Brown Strap</p>
            </div>
            <div className="date">
              <span>4/10/2022</span>
            </div>
          </div><div className="card">
            <div className="favorite">
              <Heart></Heart>
            </div>
            <div className="image">
              <img src="../../../Images/table.jpg" alt="" />
            </div>
            <div className="content">
              <p className="rate">&#x20B9; 27,000</p>
              <span className="kilometer">Wooden Dining Table </span>
              <p className="name">Chairs Also Available</p>
            </div>
            <div className="date">
              <span>12/10/2022</span>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}

export default Posts;
